		<style>
			.inp2551mP2{
				width: 144px;
				height: 21px;
				background:transparent;
				border:none;
			}
			.inp2551mP22{
				width: 324px;
				height: 21px;
				background:transparent;
				border:none;
			}
			.inp2551mP23{
				width: 241px;
				height: 21px;
				background:transparent;
				border:none;
			}
			.inp2551mP24{
				width: 257px;
				height: 21px;
				background:transparent;
				border:none;
			}
			.inp2551mP25{
				width: 201px;
				height: 21px;
				background:transparent;
				border:none;
			}
		</style>
		<link href="<?= $this->imageUrl2 ?>styles.css" rel="stylesheet" type="text/css">
	<div>
		<div id="background2">
			<div id="M2551page2"><img src="<?= $this->imageUrl2 ?>images/M2551page2.png"></div>
			
			
			
			<div id="sched1PC1"><input text="text" class="inp2551mP2"/></div>
			<div id="sched1NWA1"><input text="text" class="inp2551mP22"/></div>
			<div id="sched1IP1"><input text="text" class="inp2551mP23"/></div>
			<div id="sched1TW1"><input text="text" class="inp2551mP24"/></div>
			<div id="shced1A1"><input text="text" class="inp2551mP25"/></div>
			
			<div id="sched1PC2"><input text="text" class="inp2551mP2"/></div>
			<div id="sched1NWA2"><input text="text" class="inp2551mP22"/></div>
			<div id="sched1IP2"><input text="text" class="inp2551mP23"/></div>
			<div id="sched1TW2"><input text="text" class="inp2551mP24"/></div>
			<div id="sched1A2"><input text="text" class="inp2551mP25"/></div>
			
			<div id="sched1PC3"><input text="text" class="inp2551mP2"/></div>
			<div id="sched1NWA3"><input text="text" class="inp2551mP22"/></div>
			<div id="sched1IP3"><input text="text" class="inp2551mP23"/></div>
			<div id="sched1TW3"><input text="text" class="inp2551mP24"/></div>
			<div id="sched1A3"><input text="text" class="inp2551mP25"/></div>
			
			<div id="sched1PC4"><input text="text" class="inp2551mP2"/></div>
			<div id="sched1NWA4"><input text="text" class="inp2551mP22"/></div>
			<div id="sched1IP4"><input text="text" class="inp2551mP23"/></div>
			<div id="sched1TW4"><input text="text" class="inp2551mP24"/></div>
			<div id="schde1A4"><input text="text" class="inp2551mP25"/></div>
			
			<div id="sched1PC5"><input text="text" class="inp2551mP2"/></div>
			<div id="sched1NWA5"><input text="text" class="inp2551mP22"/></div>
			<div id="sched1IP5"><input text="text" class="inp2551mP23"/></div>
			<div id="sched1TW5"><input text="text" class="inp2551mP24"/></div>
			<div id="sched1A5"><input text="text" class="inp2551mP25"/></div>
			
			<div id="sched1PC6"><input text="text" class="inp2551mP2"/></div>
			<div id="sched1NWA6"><input text="text" class="inp2551mP22"/></div>
			<div id="sched1IP6"><input text="text" class="inp2551mP23"/></div>
			<div id="sched1TW6"><input text="text" class="inp2551mP24"/></div>
			<div id="sched1A6"><input text="text" class="inp2551mP25"/></div>
			
			<div id="sched1PC7"><input text="text" class="inp2551mP2"/></div>
			<div id="schedNWA7"><input text="text" class="inp2551mP22"/></div>
			<div id="sched1IP7"><input text="text" class="inp2551mP23"/></div>
			<div id="shced1TW7"><input text="text" class="inp2551mP24"/></div>
			<div id="sched1A7"><input text="text" class="inp2551mP25"/></div>
			
			
			<div id="sched1IPtotal"><input text="text" class="inp2551mP23"/></div>
			<div id="sched1TWtotal"><input text="text" class="inp2551mP24"/></div>
			<div id="sched1Atotal"><input text="text" class="inp2551mP25"/></div>
			
		</div>
	</div>