$(function(){
	$('input[name="item1"],' + 
		' input[name="item5[]"],' + 
		' input[name="item6"],' + 
		' input[name="item7"],' + 
		' input[name="item8"],' + 
		' input[name="item9"],' + 
		' input[name="item10"],' + 
		' input[name="item11"],' + 
		' input[name="part2Item15"],' + 
		' input[name="part2Item18"],' + 
		' input[name="part2Item16C"],' + 
		' input[name="part2Item17"],' + 
		' input[name="part2Item20"],' + 
		' input[name="part2Item22"],' + 
		' input[name="part2Item23"],' + 
		' input[name="part2Item24D"],' + 
		' input[name="part2Item25"]'
	).prop('readonly',true);
});